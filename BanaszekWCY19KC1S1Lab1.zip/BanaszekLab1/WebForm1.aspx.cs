﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanaszekLab1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((RadioButtonList)sender).SelectedValue == "small"){
                FBObrazek1.Width = 30;
                FBObrazek1.Height = 30;
                FBObrazek2.Width = 30;
                FBObrazek2.Height = 30; 
                FBObrazek3.Width = 30;
                FBObrazek3.Height = 30;
                FBObrazek4.Width = 30;
                FBObrazek4.Height = 30;
                FBObrazek5.Width = 30;
                FBObrazek5.Height = 30;
            }

            else if(((RadioButtonList)sender).SelectedValue == "medium"){
                FBObrazek1.Width = 45;
                FBObrazek1.Height = 45;
                FBObrazek2.Width = 45;
                FBObrazek2.Height = 45;
                FBObrazek3.Width = 45;
                FBObrazek3.Height = 45;
                FBObrazek4.Width = 45;
                FBObrazek4.Height = 45;
                FBObrazek5.Width = 45;
                FBObrazek5.Height = 45;

            }

            else if(((RadioButtonList)sender).SelectedValue == "big"){
                FBObrazek1.Width = 60;
                FBObrazek1.Height = 60;
                FBObrazek2.Width = 60;
                FBObrazek2.Height = 60;
                FBObrazek3.Width = 60;
                FBObrazek3.Height = 60;
                FBObrazek4.Width = 60;
                FBObrazek4.Height = 60;
                FBObrazek5.Width = 60;
                FBObrazek5.Height = 60;

            }


        }

        protected void FBDropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (((DropDownList)sender).SelectedValue == "kostka") {
                FBObrazek1.CssClass = "topleft";
                FBObrazek2.CssClass = "topright";
                FBObrazek3.CssClass = "botleft";
                FBObrazek4.CssClass = "botright";
                FBObrazek5.CssClass = "centre";

            }
            else if (((DropDownList)sender).SelectedValue == "prawaprz")
            {
                FBObrazek1.CssClass = "topright";
                FBObrazek2.CssClass = "rightup";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "leftdown";
                FBObrazek5.CssClass = "botleft";
            }

            else if (((DropDownList)sender).SelectedValue == "lewaprz")
            {
                FBObrazek1.CssClass = "topleft";
                FBObrazek2.CssClass = "leftup";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "rightdown";
                FBObrazek5.CssClass = "botright";

            }

            else if (((DropDownList)sender).SelectedValue == "liniapoz")
            {
                FBObrazek1.CssClass = "midleftfar";
                FBObrazek2.CssClass = "midleft";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "midright";
                FBObrazek5.CssClass = "midrightfar";
            }

            else if (((DropDownList)sender).SelectedValue == "liniapion")
            {
                FBObrazek1.CssClass = "midtop";
                FBObrazek2.CssClass = "midup";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "midlow";
                FBObrazek5.CssClass = "midbot";
            }

        }
    }
}