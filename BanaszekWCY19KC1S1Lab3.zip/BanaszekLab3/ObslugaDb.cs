﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;

namespace BanaszekLab2
{
    public class ObslugaDb
    {
        private static string FB_connection_sting = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        private static string FB_active = "select * from FBTabela where Active='True'";




        public static ArrayList getDB() { 
            return getListaDB("select Nazwa,DataUr,GodzUr,UsrCnt,RozCnt from FBTabela;");
        }
        public static ArrayList getZalogowani() {
            return getListaDB(FB_active);
        }


        public static void rejestracja(string FBNazwa) {
            ExecuteTask("insert into FBTabela(Nazwa,Active,DataUr,GodzUr,UsrCnt,RozCnt) values('" + FBNazwa+"',1,'"+ DateTime.Now.ToString("dd/MM/yyyy") +"','"+ DateTime.Now.ToString("HH:mm")+"',0,0)");
        }


        public static void logowanie(string FBNazwa){
            ExecuteTask("update FBTabela set Active=1,DataUr='"+ DateTime.Now.ToString("dd/MM/yyyy")+"',GodzUr='"+ DateTime.Now.ToString("HH:mm") +"' where Nazwa='"+FBNazwa+"';");
        }
        


        public static void wylogowanie(string FBNazwa) {
            ExecuteTask("update FBTabela set Active = 0 where Nazwa='"+FBNazwa+"';");
        }

        public static void zmianaRozmiaru(string FBNazwa) {
            ExecuteTask("update FBTabela set RozCnt = RozCnt+1 where Nazwa='"+FBNazwa+"';");
        }

        public static void zmianaKsztaltu(string FBNazwa)
        {
            ExecuteTask("update FBTabela set UsrCnt = UsrCnt+1 where Nazwa='" + FBNazwa + "';");
        }

        public static void killUsers() {
            ExecuteTask("update FBTabela set Active = 0;");

        }



        public static ArrayList getListaDB(string FBtask) {
            Debug.WriteLine("Hello");
            ArrayList FBListDB = new ArrayList();
            SqlConnection FBconn = new SqlConnection(FB_connection_sting);
            SqlCommand FBCommand = new SqlCommand(FBtask,FBconn);
            try
            {
                FBconn.Open();
                SqlDataReader FBReader = FBCommand.ExecuteReader();
                while (FBReader.Read()) {
                    String teststr = (String)FBReader[0];
                    String teststr2 = (String)FBReader[1];
                    int teststr3 = (int)FBReader[3];
                    Uzytkownik FBUser = new Uzytkownik((String)FBReader[0], (String)FBReader[1], (String)FBReader[2], (int)FBReader[3], (int)FBReader[4]);
                    FBListDB.Add(FBUser);
                }
                FBReader.Close();
            }
            catch (Exception e) { 
            }

            return FBListDB;

        }

        public static int getUsersNumber()
        {

            SqlConnection FBconn = new SqlConnection(FB_connection_sting);
            SqlCommand FBCommand = new SqlCommand("select count(*) from FBTabela", FBconn);
            int usercnt=0;
            try
            {
                FBconn.Open();
                SqlDataReader FBReader = FBCommand.ExecuteReader();
                FBReader.Read();
                usercnt=(int)FBReader[0];
                FBReader.Close();
            }
            catch (Exception e)
            {
            }

            return usercnt;

        }

        public static void ExecuteTask(string FBTask) {
            ArrayList FBListDB = new ArrayList();
            SqlConnection FBconn = new SqlConnection(FB_connection_sting);
            SqlCommand FBCommand = new SqlCommand(FBTask, FBconn);
            try {
                FBconn.Open();
                FBCommand.ExecuteNonQuery();
            }
            catch (Exception e){
            }  
        }
    }
}