﻿using System;
using System.Collections;

namespace BanaszekLab2
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            Session["RegUser"] = "";
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {
            ObslugaDb.wylogowanie(Session["RegUser"].ToString());
        }

        protected void Application_End(object sender, EventArgs e)
        {
            ObslugaDb.killUsers();
        }
    }
}