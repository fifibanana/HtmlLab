﻿using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanaszekLab2
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((RadioButtonList)sender).SelectedValue == "small")
            {
                FBObrazek1.Width = 30;
                FBObrazek1.Height = 30;
                FBObrazek2.Width = 30;
                FBObrazek2.Height = 30;
                FBObrazek3.Width = 30;
                FBObrazek3.Height = 30;
                FBObrazek4.Width = 30;
                FBObrazek4.Height = 30;
                FBObrazek5.Width = 30;
                FBObrazek5.Height = 30;
                zmianaRoz();

            }

            else if (((RadioButtonList)sender).SelectedValue == "medium")
            {
                FBObrazek1.Width = 45;
                FBObrazek1.Height = 45;
                FBObrazek2.Width = 45;
                FBObrazek2.Height = 45;
                FBObrazek3.Width = 45;
                FBObrazek3.Height = 45;
                FBObrazek4.Width = 45;
                FBObrazek4.Height = 45;
                FBObrazek5.Width = 45;
                FBObrazek5.Height = 45;
                zmianaRoz();

            }

            else if (((RadioButtonList)sender).SelectedValue == "big")
            {
                FBObrazek1.Width = 60;
                FBObrazek1.Height = 60;
                FBObrazek2.Width = 60;
                FBObrazek2.Height = 60;
                FBObrazek3.Width = 60;
                FBObrazek3.Height = 60;
                FBObrazek4.Width = 60;
                FBObrazek4.Height = 60;
                FBObrazek5.Width = 60;
                FBObrazek5.Height = 60;
                zmianaRoz();
            }
            stats(sender, e);
            statsSwitch();

        }

        protected void FBDropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (((DropDownList)sender).SelectedValue == "kostka")
            {
                FBObrazek1.CssClass = "topleft";
                FBObrazek2.CssClass = "topright";
                FBObrazek3.CssClass = "botleft";
                FBObrazek4.CssClass = "botright";
                FBObrazek5.CssClass = "centre";
                zmianaPoz();


            }
            else if (((DropDownList)sender).SelectedValue == "prawaprz")
            {
                FBObrazek1.CssClass = "topright";
                FBObrazek2.CssClass = "rightup";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "leftdown";
                FBObrazek5.CssClass = "botleft";
                zmianaPoz();
            }

            else if (((DropDownList)sender).SelectedValue == "lewaprz")
            {
                FBObrazek1.CssClass = "topleft";
                FBObrazek2.CssClass = "leftup";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "rightdown";
                FBObrazek5.CssClass = "botright";
                zmianaPoz();

            }

            else if (((DropDownList)sender).SelectedValue == "liniapoz")
            {
                FBObrazek1.CssClass = "midleftfar";
                FBObrazek2.CssClass = "midleft";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "midright";
                FBObrazek5.CssClass = "midrightfar";
                zmianaPoz();
            }

            else if (((DropDownList)sender).SelectedValue == "liniapion")
            {
                FBObrazek1.CssClass = "midtop";
                FBObrazek2.CssClass = "midup";
                FBObrazek3.CssClass = "centre";
                FBObrazek4.CssClass = "midlow";
                FBObrazek5.CssClass = "midbot";
                zmianaPoz();
            }
            stats(sender, e);
            statsSwitch();
        }


        protected void FBButton1_Click(object sender, EventArgs e)
        {
            //ArrayList FB_ListaUz = (ArrayList)Application["RegisteredUsers"];
            Session["RegUser"] = FBLoginBox.Text;
            Uzytkownik ux = null;



            foreach (Uzytkownik u in ObslugaDb.getZalogowani())
            {
                if (u.ImieNazwisko == FBLoginBox.Text)
                {
                    CustomValidator1.IsValid = false;
                }
            }
 
            if (Page.IsValid)
            {
                foreach (Uzytkownik u in ObslugaDb.getDB())
                {
                    if (u.ImieNazwisko == FBLoginBox.Text)
                    {
                        CustomValidator1.IsValid = false;
                        ObslugaDb.logowanie(u.ImieNazwisko);
                        ux = u;
                        break;
                    }
                }
                if (ux == null) { ObslugaDb.rejestracja(FBLoginBox.Text); }
                FBPanel1.Visible = false;
                FBPanel2.Visible = true;
                RejUzyt.Text = Session["RegUser"].ToString();
                FBDropDownList2.Items.Add(Session["RegUser"].ToString());
                stats(sender, e);
            }

        }

        public void zmianaPoz()
        {
            ArrayList FB_ListaUz = ObslugaDb.getDB();
            foreach (Uzytkownik FBuzytkownik in FB_ListaUz)
            {
                if (FBuzytkownik.ImieNazwisko == (Session["RegUser"].ToString()))
                {
                    FBuzytkownik.liczbaKsz++;
                    ObslugaDb.zmianaKsztaltu(FBuzytkownik.ImieNazwisko);
                    FBLabel3.Text = FBuzytkownik.liczbaRoz.ToString();
                    FBLabel5.Text = FBuzytkownik.liczbaKsz.ToString();
                    FBLabel7.Text = FBuzytkownik.data.ToString();
                    FBLabel13.Text = FBuzytkownik.godzina.ToString();
                }
            }

        }

        public void zmianaRoz()
        {
            ArrayList FB_ListaUz = ObslugaDb.getDB();

            foreach (Uzytkownik FBuzytkownik in FB_ListaUz)
            {
                if (FBuzytkownik.ImieNazwisko == (Session["RegUser"].ToString()))
                {
                    FBuzytkownik.liczbaRoz++;
                    ObslugaDb.zmianaRozmiaru(FBuzytkownik.ImieNazwisko);
                    FBLabel5.Text = FBuzytkownik.liczbaKsz.ToString();
                    FBLabel3.Text = FBuzytkownik.liczbaRoz.ToString();
                    FBLabel7.Text = FBuzytkownik.data.ToString();
                    FBLabel13.Text = FBuzytkownik.godzina.ToString();
                }
            }

        }

        protected void FBDropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            statsSwitch();
        }

        protected void stats(object sender, EventArgs e)
        {
            ArrayList FB_ListaUz = ObslugaDb.getZalogowani();

            String pom = Session["RegUser"].ToString();
            foreach (Uzytkownik FBuzytkownik in FB_ListaUz)
            {
                if (FBuzytkownik.ImieNazwisko == pom)
                {
                    FBLabel3.Text = FBuzytkownik.liczbaRoz.ToString();
                    FBLabel5.Text = FBuzytkownik.liczbaKsz.ToString();
                    FBLabel7.Text = FBuzytkownik.data.ToString();
                    FBLabel9.Text = FB_ListaUz.Count.ToString();
                    FBLabel11.Text = ObslugaDb.getUsersNumber().ToString();
                    FBLabel13.Text = FBuzytkownik.godzina.ToString();
                    break;
                }

            }
            dropref();
        }

        protected void dropref()
        {
            ArrayList FB_ListaUz = ObslugaDb.getZalogowani();
            String pom = Session["RegUser"].ToString();
            FBDropDownList2.Items.Clear();
            foreach (Uzytkownik FBuzytkownik in FB_ListaUz)
            {
                FBDropDownList2.Items.Add(FBuzytkownik.ImieNazwisko);
            }
            var item = FBDropDownList2.Items.FindByText(pom);
            if (item != null)
                item.Selected = true;
        }

        protected void statsSwitch()
        {
            ArrayList FB_ListaUz = ObslugaDb.getZalogowani();
            String pom = FBDropDownList2.SelectedValue.ToString();
            foreach (Uzytkownik FBuzytkownik in FB_ListaUz)
            {
                if (FBuzytkownik.ImieNazwisko == pom)
                {
                    FBLabel3.Text = FBuzytkownik.liczbaRoz.ToString();
                    FBLabel5.Text = FBuzytkownik.liczbaKsz.ToString();
                    FBLabel7.Text = FBuzytkownik.data.ToString();
                    FBLabel11.Text = ObslugaDb.getUsersNumber().ToString();
                    FBLabel13.Text = FBuzytkownik.godzina.ToString();
                    break;
                }

            }

        }


        protected void userRefresher()
        {
            ArrayList FB_ListaUz = ObslugaDb.getZalogowani(); 
            FBLabel9.Text = FB_ListaUz.Count.ToString();
 
        }


        protected void Timer1_Tick(object sender, EventArgs e)
        {
            dropref();
            userRefresher();
        }
    }
}