﻿using System;

namespace BanaszekLab2
{
    public class Uzytkownik
    {
        public String ImieNazwisko;
        public int liczbaRoz;
        public int liczbaKsz;
        public String data;
        public String godzina;

        public Uzytkownik(String ImieNazwisko)
        {
            this.ImieNazwisko = ImieNazwisko;
            liczbaRoz = 0;
            liczbaKsz = 0;
            data = DateTime.Now.ToString();
        }

        public Uzytkownik(String ImNaz, String czas,String godz ,int roz, int ksz) {
            ImieNazwisko = ImNaz;
            liczbaRoz = roz;
            liczbaKsz = ksz;
            data = czas;
            godzina = godz;
        }

    }
}