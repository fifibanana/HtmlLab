﻿using System;

namespace BanaszekLab2
{
    public class Uzytkownik
    {
        public String ImieNazwisko;
        public int liczbaRoz;
        public int liczbaKsz;
        public DateTime data;
        public Uzytkownik(String ImieNazwisko)
        {
            this.ImieNazwisko = ImieNazwisko;
            liczbaRoz = 0;
            liczbaKsz = 0;
            data = DateTime.Now;
        }

        /*public Uzytkownik wybieranie(String ImieNazwisko) {
            ArrayList FB_ListaUz = Application["RegisteredUsers"];
        }*/

    }
}