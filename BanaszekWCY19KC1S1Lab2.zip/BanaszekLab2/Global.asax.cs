﻿using System;
using System.Collections;

namespace BanaszekLab2
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            Application["RegisteredUsers"] = new ArrayList();
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            Session["RegUser"] = "";
            Session["startDate"] = DateTime.Now.ToString();
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}